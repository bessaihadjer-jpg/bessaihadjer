---
title: "AI–BIM Integration for Early-Stage Building Energy Performance Prediction"
collection: publications
category: manuscripts
permalink: /publications/ai-bim-early-energy-prediction
excerpt: 'A parametric Revit + OpenStudio workflow feeding Random Forest and XGBoost models, deployed through a custom pyRevit extension for real-time energy feedback at the earliest stage of design.'
date: 2026-01-01
venue: "Master's Thesis — EPAU (École Polytechnique d'Architecture et d'Urbanisme d'Alger)"
paperurl: '/files/thesis.pdf'
citation: 'Bessai, H. (2026). AI–BIM Integration for Early-Stage Building Energy Performance Prediction. Master&#39;s thesis, EPAU.'
---

## Motivation

Energy performance in residential design is almost always evaluated *after* the key design decisions — massing, orientation, envelope — have already been locked in, when changing course is expensive. This research asks whether performance prediction can move upstream, into the earliest and most flexible stage of the design process, without breaking a designer's workflow.

*Note to self: replace this paragraph with 2–4 sentences on why this specifically matters for Algerian residential contexts, or whatever framing you used in the thesis introduction.*

## Methodology

- **Parametric generation** — building massing and envelope variables parameterized directly in Revit to construct a controlled design space.
- **Simulation** — all 864 resulting design scenarios simulated in OpenStudio to produce ground-truth energy performance data.
- **Prediction** — Random Forest and XGBoost models trained on the simulated dataset, producing performance estimates in milliseconds instead of the minutes a full simulation run requires.
- **Deployment** — the trained models packaged into a custom pyRevit extension (see [Projects](/portfolio/)), surfacing predictions directly inside the Revit modeling environment.

*Note to self: add your actual figures here (parametric variable diagram, workflow diagram, predicted-vs-simulated scatter plot) as images, and swap in real accuracy metrics (R² / RMSE) once you're ready to publish them.*

## Results

*Note to self: 2–3 sentences summarizing your key findings — model accuracy achieved, how much faster the ML prediction was vs. full simulation, and what this means for early-design decision-making.*

## Files

- [Download full thesis (PDF)](/files/thesis.pdf) — *replace with your real file in `/files/thesis.pdf`*
- [Download extended abstract (PDF)](/files/thesis-abstract.pdf) — *optional, replace or remove*
