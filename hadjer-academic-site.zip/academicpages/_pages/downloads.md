---
layout: single
title: "Downloads"
permalink: /downloads/
author_profile: true
---

Everything a professor usually asks for, in one place. Replace each `#` below with a real file path once you've added the PDF to the `files/` folder (e.g. `/files/cv.pdf`).

- [CV](/files/cv.pdf){: .btn .btn--primary}
- [Research Statement](#){: .btn .btn--primary}
- [Full Thesis](/files/thesis.pdf){: .btn .btn--primary}
- [Thesis Abstract](#){: .btn .btn--primary}
- [Selected Works Portfolio](#){: .btn .btn--primary}
- [Recommendation Letters](#){: .btn .btn--primary} *(optional — only include if you have letters cleared for public sharing; otherwise remove this line and offer it on request instead)*

*Note to self: this mirrors the file order you've been using for PhD applications (Statement of Interest, CV, Programming Skills, Research Summary, Selected Works Portfolio, Academic Transcripts & Diplomas) — add or rename items above to match exactly.*
