---
permalink: /
title: "Hadjer Bessai — Architect · BIM Researcher"
author_profile: true
redirect_from:
  - /about/
  - /about.html
---

Architect | BIM Researcher | Prospective PhD Researcher
======
I work at the intersection of **AI, Building Information Modelling (BIM), computational design, building performance simulation, and digital twins** for the built environment. My research asks how we can move energy performance evaluation from an after-the-fact check into a real-time input at the earliest, most flexible stage of architectural design.

<!-- Buttons — replace the # links below with your real CV file, LinkedIn, and email -->
[Download CV](/files/cv.pdf){: .btn .btn--primary} [Google Scholar](#){: .btn .btn--info} [LinkedIn](#){: .btn .btn--info} [Email me](mailto:your.email@example.com){: .btn .btn--info}

About Me
======
I am an architecture graduate of **EPAU** (École Polytechnique d'Architecture et d'Urbanisme d'Alger), holding a **Diplôme d'État en Architecture** and a **Master's degree in BIM (with Distinction)**. My work sits deliberately between two disciplines: architectural design and computational research, with a technical grounding in machine learning and building performance simulation.

My master's thesis developed a workflow for **AI–BIM integration for early-stage building energy performance prediction**, combining a parametric Revit + OpenStudio dataset of 864 design scenarios with Random Forest and XGBoost models, deployed through a custom pyRevit extension that gives designers real-time performance feedback directly inside Revit — see the [Research](/publications/) and [Projects](/portfolio/) pages for details.

I am currently pursuing fully funded doctoral research positions abroad, focused on programs at the intersection of AI, BIM, computational design, and building energy/performance research.

**Research interests:** AI for the built environment · Building Information Modelling (BIM) · Computational design · Building performance simulation · Digital twins · Machine learning for architecture & construction

*Note to self before publishing: add a professional portrait as `images/profile.png` (square, ~400×400px works best), and fill in the CV/LinkedIn/email links above.*
