---
layout: archive
title: "CV"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

{% include base_path %}

[Download full CV as PDF](/files/cv.pdf){: .btn .btn--primary}
*Note to self: put your actual CV PDF at `files/cv.pdf` — the button above already points there.*

Education
======
* Master's degree in BIM (Distinction) — EPAU (École Polytechnique d'Architecture et d'Urbanisme d'Alger)
* Diplôme d'État en Architecture — EPAU
  *Note to self: add exact years and thesis title here.*

Research Skills
======
* Building Information Modelling (BIM) — Revit
* Building performance simulation — OpenStudio
* Computational design — Grasshopper
* Programming — Python
* Machine learning — Random Forest, XGBoost
* Digital twins for the built environment

Software & Tools
======
* Revit, Rhino/Grasshopper, SketchUp, AutoCAD
* OpenStudio, Python
* D5 Render, Photoshop, Illustrator, After Effects

Talks & Involvement
======
* TEDxEPAU — license holder and organizer
  *Note to self: add specific talk titles/dates if applicable.*

Publications
======
  <ul>{% for post in site.publications reversed %}
    {% include archive-single-cv.html %}
  {% endfor %}</ul>

*Note to self: add Work Experience, Awards, and Languages sections once you decide what to include — keep this page tight and scannable; a professor should be able to read the whole thing in under two minutes.*
