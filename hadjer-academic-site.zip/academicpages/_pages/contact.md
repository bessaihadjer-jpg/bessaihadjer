---
layout: single
title: "Contact"
permalink: /contact/
author_profile: true
---

The fastest way to reach me is by email.

- **Email:** [your.email@example.com](mailto:your.email@example.com) *(replace with your real address)*
- **LinkedIn:** [add your profile link](#)
- **GitHub:** [add your profile link](#)

*Note to self: once your CV/LinkedIn/GitHub links are finalized here and in `_config.yml`, they'll also automatically appear as icons in the sidebar on every page.*
